<?php

namespace App\Livewire\Views\Inventory\Orders;

use Livewire\Component;

class All extends Component
{
    public function render()
    {
        return view('livewire.views.inventory.orders.all');
    }
}

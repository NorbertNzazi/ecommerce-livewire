<?php

namespace App\Livewire\Views\Admin;

use Livewire\Component;

class Category extends Component
{
    public function render()
    {
        return view('livewire.views.admin.category');
    }
}

<?php

namespace App\Livewire\Views\Admin;

use Livewire\Component;

class Order extends Component
{
    public function render()
    {
        return view('livewire.views.admin.order');
    }
}

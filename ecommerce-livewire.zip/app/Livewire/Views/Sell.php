<?php

namespace App\Livewire\Views;

use Livewire\Component;

class Sell extends Component
{
    public function render()
    {
        return view('livewire.views.sell');
    }
}

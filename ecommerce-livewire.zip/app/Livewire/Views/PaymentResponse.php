<?php

namespace App\Livewire\Views;

use Livewire\Component;

class PaymentResponse extends Component
{
    public function render()
    {
        return view('livewire.views.payment-response');
    }
}

<?php

namespace App\Livewire\Components;

use Livewire\Component;

class SearchInput extends Component
{
    public function render()
    {
        return view('livewire.components.search-input');
    }
}

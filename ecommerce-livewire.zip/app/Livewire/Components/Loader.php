<?php

namespace App\Livewire\Components;

use Livewire\Component;

class Loader extends Component
{
    public function render()
    {
        return view('livewire.components.loader');
    }
}

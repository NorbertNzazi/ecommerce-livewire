<div>

    <!-- Shoping Cart Section Begin -->
    <section class="shoping-cart spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="shoping__cart__table">
                        <table>
                            <thead>
                                <tr>
                                    <th class="shoping__product">Products</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th></th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php if (! (count($cartItems) > 0)): ?>
                                    <p>No items found</p>
                                <?php else: ?>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cartItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr wire:key="<?php echo e($cartItem->cart_item_id); ?>">

                                            <div wire:loading wire:target="removeFromCart(<?php echo e($cartItem->cart_item_id); ?>)">
                                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, '5ZTXNbg', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                            </div>

                                            <td class="shoping__cart__item">
                                                <img src="<?php echo e(asset($cartItem->product->image)); ?>" alt="">
                                                <h5><?php echo e($cartItem->product->name); ?></h5>
                                            </td>
                                            <td class="shoping__cart__price">
                                                R<?php echo e($cartItem->product->price); ?>

                                            </td>
                                            <td class="shoping__cart__quantity">
                                                <div class="quantity">
                                                    <div class="pro-qty">
                                                        <input type="number" min="1" value="<?php echo e($cartItem->qty); ?>"
                                                            wire:model.live="newQty.<?php echo e($cartItem->cart_item_id); ?>">
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="shoping__cart__total">
                                                R<?php echo e($cartItem->product->price * $cartItem->qty); ?>

                                            </td>

                                            <td class="shoping__cart__item__close">
                                                <span style="color: green; margin-right:50px;"
                                                    wire:click="updateQty(<?php echo e($cartItem->cart_item_id); ?>)"
                                                    class="icon_check">
                                                </span>
                                            </td>

                                            <td class="shoping__cart__item__close">
                                                <span style="color: red;"
                                                    wire:click="removeFromCart(<?php echo e($cartItem->cart_item_id); ?>)"
                                                    wire:confirm="Remove item?" class="icon_close">
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-6">
                    <div class="shoping__cart__btns">
                        <a style="background-color: #000;border-radius:5px;color:#fff;" href="<?php echo e(route('home')); ?>"
                            class="primary-btn cart-btn">CONTINUE SHOPPING</a>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="shoping__checkout" style="background-color: #000;border-radius:5px;">
                        <h5 style="color:#fff;">Cart Total: R<?php echo e($cartItemsTotal); ?></h5>
                        
                        <a style="border-radius:5px;" href="<?php echo e(route('checkout')); ?>" class="primary-btn">PROCEED TO
                            CHECKOUT</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Shoping Cart Section End -->

</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/cart.blade.php ENDPATH**/ ?>
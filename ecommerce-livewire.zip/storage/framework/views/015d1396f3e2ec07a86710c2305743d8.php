<div>
    <!-- Checkout Section Begin -->
    <section class="checkout spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-end">
                    <h6>
                        Forgot your password? <a href="#">Click here</a> to
                        request a reset password link
                    </h6>
                </div>
            </div>

            <div class="checkout__form">
                <h3>Store In</h3>

                <div wire:loading wire:target="checkEmail()">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, 'Zhlxsc6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

                <!--[if BLOCK]><![endif]--><?php if(!$emailProcessed): ?>
                    <form wire:submit.prevent="checkEmail">
                        <div class="row flex justify-center align-center">
                            <div class="col-lg-3 col-md-12">
                            </div>

                            <div class="checkout__order" style="background-color: #cfcfcf;border-radius:5px;width:50%;">

                                
                                <div class="checkout__input">
                                    <p>Email Address
                                        <span>*
                                            <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                        </span>
                                    </p>
                                    <input type="email" wire:model.live="email">
                                </div>


                                
                                <!--[if BLOCK]><![endif]--><?php if($email): ?>
                                    <div class="checkout__input">
                                        <button type="submit" class="site-btn" style="background-color: #000;">
                                            Submit
                                        </button>
                                    </div>
                                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->


                                <p>
                                    Please enter your email address to continue
                                </p>

                            </div>

                            <div class="col-lg-3 col-md-12">
                            </div>
                        </div>
                    </form>
                <?php else: ?>
                    <!--[if BLOCK]><![endif]--><?php if($auth == 'login'): ?>
                        <form wire:submit.prevent="login">
                            <div class="row flex justify-center align-center">
                                <div class="col-lg-3 col-md-12">
                                </div>

                                <div class="checkout__order"
                                    style="background-color: #cfcfcf;border-radius:5px;width:50%;">

                                    
                                    <div class="checkout__input">
                                        <p>Email Address
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="email" wire:model.live="email" <?php if($emailProcessed): echo 'disabled'; endif; ?>>
                                    </div>


                                    
                                    <div class="checkout__input">
                                        <p>Password
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo e($message); ?>

                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="password" wire:model.live="password">
                                    </div>

                                    <!--[if BLOCK]><![endif]--><?php if($password && $email): ?>
                                        <div class="checkout__input">
                                            <button type="submit" class="site-btn" style="background-color: #000;">
                                                <?php echo e($auth == 'login' ? 'Login' : 'Register'); ?>

                                            </button>
                                        </div>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="col-lg-3 col-md-12">
                                </div>
                            </div>
                        </form>
                    <?php else: ?>
                        <form wire:submit.prevent="register">
                            <div class="row flex justify-center align-center">
                                <div class="col-lg-3 col-md-12">
                                </div>

                                <div class="checkout__order"
                                    style="background-color: #cfcfcf;border-radius:5px;width:50%;">

                                    
                                    <div class="checkout__input">
                                        <p>Email
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo $__env->make('components.field-error', [
                                                        'message' => $message,
                                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="email" wire:model.live="email" <?php if($emailProcessed): echo 'disabled'; endif; ?>>
                                    </div>


                                    <div class="checkout__input">
                                        <p>Name
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo $__env->make('components.field-error', [
                                                        'message' => $message,
                                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="text" wire:model.live="name">
                                    </div>


                                    <div class="checkout__input">
                                        <p>Surname
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo $__env->make('components.field-error', [
                                                        'message' => $message,
                                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="text" wire:model.live="surname">
                                    </div>


                                    
                                    <div class="checkout__input">
                                        <p>Password
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo $__env->make('components.field-error', [
                                                        'message' => $message,
                                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="password" wire:model.live="password">
                                    </div>


                                    
                                    <div class="checkout__input">
                                        <p>Password Confirmation
                                            <span>*
                                                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['passwordConfirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <?php echo $__env->make('components.field-error', [
                                                        'message' => $message,
                                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <!--[if ENDBLOCK]><![endif]-->
                                            </span>
                                        </p>
                                        <input type="password" wire:model.live="passwordConfirmation">
                                    </div>

                                    <!--[if BLOCK]><![endif]--><?php if($password && $email && $name && $surname): ?>
                                        <div class="checkout__input">
                                            <button type="submit" class="site-btn" style="background-color: #000;">
                                                Submit
                                            </button>
                                        </div>
                                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                                </div>

                                <div class="col-lg-3 col-md-12">
                                </div>
                            </div>
                        </form>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
            </div>
        </div>
    </section>
    <!-- Checkout Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/auth/access.blade.php ENDPATH**/ ?>
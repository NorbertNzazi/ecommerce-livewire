<div>
    <div class="hero__search d-flex align-items-center;">
        <div class="hero__search__form" style="width:100%;">
            <form>
                <input style="width:100%;" type="text" placeholder="Search for a product">
            </form>
        </div>
    </div>

    <h2 style="text-align:center;" class="mb-5">Order Products</h2>

    <!--[if BLOCK]><![endif]--><?php if(Session::has('success')): ?>
        <?php echo $__env->make('components.alert', [
            'message' => Session::get('success'),
            'type' => 'success',
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

    <div class="filter__item">
        <div class="row">
            <div class="col-lg-4 col-md-5">
                <div class="filter__sort">
                    <span>Sort By</span>
                    <select>
                        <option value="0">Default</option>
                        <option value="name-asc">Name-Asc</option>
                        <option value="name-desc">Name-Desc</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-4 col-md-4">
                <div class="filter__found">
                    <h6><span>15</span> Products found</h6>
                </div>
            </div>
            <div class="col-lg-4 col-md-3">
                <div class="filter__option">
                    <span class="icon_grid-2x2"></span>
                    <span class="icon_ul"></span>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <?php if (! (count($orderItems) > 0)): ?>
            <h3>Select an order to view products</h3>
        <?php else: ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="product__item">

                        <div wire:key="<?php echo e($orderItem['order']['order_item_id']); ?>" class="product__item__pic set-bg"
                            data-setbg="<?php echo e(asset('storage/' . $orderItem['product']['image'])); ?>">
                        </div>

                        <div class="product__item__text">
                            <h6>
                                <a><?php echo e($orderItem['product']['name']); ?></a>
                            </h6>

                            <p>R<?php echo e($orderItem['product']['amount']); ?>

                            </p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/shop/user/order-items.blade.php ENDPATH**/ ?>
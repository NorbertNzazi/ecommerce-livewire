<div>
    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'NUtSLK6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>


                <div class="col-lg-9">
                    <div class="hero__search">
                        <div class="hero__search__form">
                            <form>
                                <input style="width:100%;" type="text" placeholder="Search for a product">
                            </form>
                        </div>

                        <div class="hero__search__phone">
                            <div class="hero__search__phone__icon">
                                <i class="fa fa-phone"></i>
                            </div>
                            <div class="hero__search__phone__text">
                                <h5>+27 606 447 885</h5>
                                <span>Support 24/7 </span>
                            </div>
                        </div>
                    </div>

                    <div class="filter__item">
                        <div class="row">
                            <div class="col-lg-4 col-md-5">
                                <div class="filter__sort">
                                    <span>Sort By</span>
                                    <select>
                                        <option value="0">Default</option>
                                        <option value="name-asc">Name-Asc</option>
                                        <option value="name-desc">Name-Desc</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="filter__found">
                                    <h6><span><?php echo e(count($items)); ?></span> Product(s) found</h6>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3">
                                <div class="filter__option">
                                    <span class="icon_grid-2x2"></span>
                                    <span class="icon_ul"></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <?php if (! (count($items) > 0)): ?>
                            <h3>No items found in store</h3>
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:key="<?php echo e($item->product_id); ?>" class="col-lg-3 col-md-6 col-sm-6">
                                    <div class="product__item" style="cursor: pointer;"
                                        wire:click="viewItem(<?php echo e($item->product_id); ?>)">

                                        <div wire:loading wire:target="addToCart(<?php echo e($item->product_id); ?>)">
                                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, 'rNPYkb1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        </div>

                                        <div class="product__item__pic set-bg"
                                            data-setbg="<?php echo e(asset('storage/' . $item->image)); ?>">
                                        </div>

                                        <span style="color:<?php echo e($item->qty == 0 ? 'red' : 'green'); ?>;font-weight:bold;">
                                            <?php echo e($item->qty == 0 ? 'Out of stock' : 'In stock'); ?>

                                        </span>

                                        <div class="product__item__text">
                                            <h6>
                                                <a><?php echo e($item->name); ?></a>

                                            </h6>

                                            <h5 style="color: <?php echo e($item->user_id ? null : 'red'); ?>">
                                                <?php echo e($item->user_id ? 'R' . $item->price : 'Display product'); ?></h5>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/home.blade.php ENDPATH**/ ?>
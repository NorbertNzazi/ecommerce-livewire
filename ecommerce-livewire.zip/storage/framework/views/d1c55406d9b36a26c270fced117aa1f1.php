<div class="hero__categories">
    <div class="hero__categories__all">
        <i class="fa fa-bars"></i>
        <span>My Orders</span>
    </div>
    <ul>
        <?php if (! (count($orders) > 0)): ?>
            <li>No orders yet</li>
        <?php else: ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li wire:key="<?php echo e($order->order_id); ?>" wire:click="selectOrder(<?php echo e($order->order_id); ?>)"> #
                    <?php echo e($order->created_at); ?> <span
                        style="text-align: end;color:green;font-weight:bold;"><?php echo e(' R' . $order->amount); ?>

                    </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/shop/user/order-selection.blade.php ENDPATH**/ ?>
<div>
    <!-- Page Preloder -->
    
    <div class="lds-roller">
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
        <div></div>
    </div>
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/components/loader.blade.php ENDPATH**/ ?>
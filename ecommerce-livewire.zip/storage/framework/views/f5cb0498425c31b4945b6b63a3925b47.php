<div>
    <!-- Product Details Section Begin -->
    <section class="product-details spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__pic">
                        <div class="product__details__pic__item">
                            <img class="product__details__pic__item--large"
                                src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6">
                    <div class="product__details__text">
                        <h3><?php echo e($product->name); ?></h3>
                        
                        <div class="product__details__price">R<?php echo e($product->price); ?></div>
                        <p><?php echo e($product->description); ?></p>
                        <div class="product__details__quantity">
                            <div class="quantity">
                                <div class="pro-qty">
                                    <input type="number" value="1"
                                        style="background-color: #000;border-radius:10px;color:#fff;"
                                        wire:model.live="qty" min="1">
                                </div>
                            </div>
                        </div>

                        <button class="primary-btn" style="border-radius:10px;border-style:none;"
                            wire:click="addToCart()">ADD
                            TO CARD
                        </button>

                        
                        <ul>
                            <li><b>Availability</b> <span
                                    style="font-weight:bold;color: <?php echo e($product->qty > 0 ? 'green' : 'red'); ?>"><?php echo e($product->qty > 0 ? 'In stock' : 'Out of stock'); ?></span>
                            </li>
                            <li><b>Shipping</b> <span>03 days shipping</li>
                            
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Product Details Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/shop/products/one.blade.php ENDPATH**/ ?>
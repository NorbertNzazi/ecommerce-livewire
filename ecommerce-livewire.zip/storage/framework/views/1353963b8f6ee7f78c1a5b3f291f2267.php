<span style="font-weight: bold;font-size:11px;color:red;">
    <?php echo e($message); ?>

</span><?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/components/field-error.blade.php ENDPATH**/ ?>
<div class="hero__search__form" style="background-color:bisque;width:100%;">
    <input type="text" placeholder="Search for a product">
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/components/search-input.blade.php ENDPATH**/ ?>
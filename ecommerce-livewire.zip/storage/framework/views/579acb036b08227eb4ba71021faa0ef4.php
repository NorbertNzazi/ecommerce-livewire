<div class="hero__categories">
    <div class="hero__categories__all" style="background-color: black;">
        <i class="fa fa-bars"></i>
        <span>Customer Orders</span>
    </div>

    <div wire:loading>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, 'ZX3ZTzC', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>

    <ul>
        <?php if (! (count($orders) > 0)): ?>
            <li>No orders yet</li>
        <?php else: ?>
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderId => $orderData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li wire:key="<?php echo e($orderId); ?>" wire:click="selectOrder(<?php echo e($orderId); ?>)">
                    #<?php echo e($orderData['order']['created_at']); ?>

                    <span style="text-align: end;color:green;font-weight:bold;"> R
                        <?php echo e($orderData['order']['amount']); ?>

                    </span>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/inventory/orders/selector.blade.php ENDPATH**/ ?>
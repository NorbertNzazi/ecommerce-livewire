<div>
    <section class="hero">
        <div class="container">

            <!--[if BLOCK]><![endif]--><?php if(Session::has('success')): ?>
                <?php echo $__env->make('components.alert', [
                    'message' => Session::get('success'),
                    'type' => 'success',
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

            <div class="row">

                <div class="col-lg-2">
                </div>

                <div class="col-lg-8">
                    <h2 style="text-align:center;" class="mb-5">Inventory Management</h2>

                    <div class="row d-flex justify-content-center align-items-center">

                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-3 col-md-6 col-sm-6">
                                <a href="<?php echo e(route($card['routeTo'])); ?>">
                                    <div class="product__item d-flex justify-content-center align-items-center"
                                        style="cursor: pointer;background-color:#e100ff;height:150px;border-radius:10px;text-align:center;color:white;">

                                        <div class="d-flex flex-column align-items-center">
                                            <span style="color: white;font-size:20px;">
                                                <?php echo e($card['title']); ?>

                                            </span>
                                            <span style="color: white;font-size:15px;">
                                                <?php echo e($card['count']); ?>

                                            </span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="col-lg-2">
                </div>
            </div>
        </div>
    </section>
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/inventory.blade.php ENDPATH**/ ?>
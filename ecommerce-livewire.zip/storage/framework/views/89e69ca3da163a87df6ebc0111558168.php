<div>
    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">

                <div class="col-lg-4">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.shop.user.order-selection', []);

$__html = app('livewire')->mount($__name, $__params, '8awsrLG', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>

                <div class="col-lg-8">
                    <h3 style="text-align:center;" class="mb-5">Order Products</h3>

                    <div class="filter__item">
                        <div class="row">
                            <div class="col-lg-4 col-md-5">
                                
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="filter__found">
                                    <h6><span><?php echo e(count($orderItems)); ?></span> Product(s) found</h6>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3">
                                <div class="filter__option">
                                    <span style="font-size:15px;">Status:</span>
                                    <span style="color: green;font-size:15px;font-weight: bold;">Paid</span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div wire:loading >
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, '7Cj0w6i', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        </div>

                        <?php if (! (count($orderItems) > 0)): ?>
                            <h3>Select an order to view products</h3>
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $orderItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:key="<?php echo e($orderItem->product->product_id); ?>" class="col-lg-3 col-md-6 col-sm-6">
                                    <div class="product__item">

                                        <div class="product__item__pic set-bg"
                                            data-setbg="<?php echo e(asset('storage/' . $orderItem->product->image)); ?>">
                                        </div>

                                        <div class="product__item__text">
                                            <h6>
                                                <a><?php echo e($orderItem->product->name); ?></a>
                                            </h6>

                                            <p>R<?php echo e($orderItem->amount); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/shop/user/order.blade.php ENDPATH**/ ?>
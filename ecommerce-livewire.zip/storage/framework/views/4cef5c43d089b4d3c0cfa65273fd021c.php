<div>
    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.admin.sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'OwEE0yh', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>


                <div class="col-lg-9">

                    <!--[if BLOCK]><![endif]--><?php if(Session::has('success')): ?>
                        <?php echo $__env->make('components.alert', [
                            'message' => Session::get('success'),
                            'type' => 'success',
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                    <div class="hero__search d-flex align-items-center;">
                        <div class="hero__search__form" style="width:100%;">
                            <form>
                                <input style="width:100%;" type="text" placeholder="Search for a product"
                                    wire:model.live="search">
                            </form>
                        </div>

                        <a href="<?php echo e(route('admin-new-user')); ?>" class="d-flex align-items-center justify-content-center"
                            style="padding-left:10px;background-color:black;width:200px;margin-left:10px;margin-bottom:5px;margin-top:5px;color:white;">
                            <i class="fa fa-plus" style="color: white;margin-right:10px;"></i>
                            Add new
                        </a>
                    </div>

                    <div class="filter__item">
                        <div class="row">
                            <div class="col-lg-4 col-md-5">
                                
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="filter__found">
                                    <h6><span><?php echo e(count($items)); ?></span> Product(s) found</h6>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3">
                                
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <?php if (! (count($items) > 0)): ?>
                            <h3>No items found in store</h3>
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:key="<?php echo e($item->product_id); ?>" class="col-lg-3 col-md-6 col-sm-6">
                                    <div class="product__item" wire:click="viewItem(<?php echo e($item->product_id); ?>)"
                                        style="cursor: pointer;">

                                        <div wire:loading wire:target="viewItem(<?php echo e($item->product_id); ?>)">
                                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, 'VonWE3k', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        </div>

                                        <div class="product__item__pic set-bg" data-setbg="<?php echo e(asset($item->image)); ?>">
                                        </div>

                                        <span style="color:<?php echo e($item->qty == 0 ? 'red' : 'green'); ?>;font-weight:bold;">
                                            <?php echo e($item->qty == 0 ? 'Out of stock' : 'In stock'); ?>

                                        </span>

                                        <div class="product__item__text">
                                            <h6>
                                                <a><?php echo e($item->name); ?></a>
                                            </h6>

                                            <h5>R<?php echo e($item->price); ?></h5>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/admin/products.blade.php ENDPATH**/ ?>
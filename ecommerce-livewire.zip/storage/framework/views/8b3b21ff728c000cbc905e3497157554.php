<div>
    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">

                <div class="col-lg-4">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.inventory.orders.selector', []);

$__html = app('livewire')->mount($__name, $__params, 'vZ2S7lq', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>


                <div class="col-lg-8">
                    <h2 style="text-align:center;" class="mb-5">Order Products</h2>

                    <!--[if BLOCK]><![endif]--><?php if(Session::has('success')): ?>
                        <?php echo $__env->make('components.alert', [
                            'message' => Session::get('success'),
                            'type' => 'success',
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/inventory/orders/all.blade.php ENDPATH**/ ?>
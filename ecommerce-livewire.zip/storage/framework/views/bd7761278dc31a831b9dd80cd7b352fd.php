<div>
    <!-- Hero Section Begin -->
    <section class="hero">
        <div class="container">
            <div class="row">

                <div class="col-lg-3">
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.admin.sidebar', []);

$__html = app('livewire')->mount($__name, $__params, 'nhBt8SV', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                </div>


                <div class="col-lg-9">

                    <!--[if BLOCK]><![endif]--><?php if(Session::has('success')): ?>
                        <?php echo $__env->make('components.alert', [
                            'message' => Session::get('success'),
                            'type' => 'success',
                        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->

                    <div class="hero__search d-flex align-items-center;">
                        <div class="hero__search__form" style="width:100%;">
                            <form>
                                <input style="width:100%;" type="text" placeholder="Search for a product"
                                    wire:model.live="search">
                            </form>
                        </div>

                        <a href="<?php echo e(route('admin-new-user')); ?>" class="d-flex align-items-center justify-content-center"
                            style="padding-left:10px;background-color:black;width:200px;margin-left:10px;margin-bottom:5px;margin-top:5px;color:white;">
                            <i class="fa fa-plus" style="color: white;margin-right:10px;"></i>
                            Add new
                        </a>
                    </div>

                    <div class="filter__item">
                        <div class="row">
                            <div class="col-lg-4 col-md-5">
                                
                            </div>
                            <div class="col-lg-4 col-md-4">
                                <div class="filter__found">
                                    <h6><span><?php echo e(count($users)); ?></span> User(s) found</h6>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-3">
                                
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <?php if (! (count($users) > 0)): ?>
                            <h3>No users found</h3>
                        <?php else: ?>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div wire:key="<?php echo e($user->user_id); ?>" class="col-lg-3 col-md-6 col-sm-6">
                                    <div class="product__item d-flex flex-column align-items-center"
                                        style="cursor: pointer;" wire:click="viewUser(<?php echo e($user->user_id); ?>)">

                                        <div wire:loading wire:target="viewUser(<?php echo e($user->user_id); ?>)">
                                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.loader', []);

$__html = app('livewire')->mount($__name, $__params, 'TUFzCvf', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        </div>

                                        <div class="product__item__pic set-bg"
                                            style="width: 80px; height: 80px; object-fit: cover; border-radius: 50%; background-image: url('<?php echo e(asset('img/profile.png')); ?>');"
                                            data-setbg="<?php echo e(asset('img/profile.png')); ?>">
                                        </div>


                                        <div class="product__item__text">
                                            <a style="color: green;"><?php echo e($user->name . ' ' . $user->surname); ?></a>
                                        </div>

                                        <span style="color: red;font-size:12px;"><?php echo e($user->email); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <!--[if ENDBLOCK]><![endif]-->
                        <?php endif; ?> <!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->
</div>
<?php /**PATH C:\Users\JP Tiyasi\Documents\Development\Practice\Norbert Alba\ecommerce-livewire\resources\views/livewire/views/admin/users.blade.php ENDPATH**/ ?>
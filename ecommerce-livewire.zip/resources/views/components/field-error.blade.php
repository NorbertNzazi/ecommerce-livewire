<span style="font-weight: bold;font-size:11px;color:red;">
    {{ $message }}
</span>
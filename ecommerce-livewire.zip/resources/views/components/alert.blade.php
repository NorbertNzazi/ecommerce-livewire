<div class="d-flex justify-content-center mb-5">
    <span
        style="font-size:15px;color:white;background-color:{{ $type == 'success' ? 'green' : 'red' }};padding-left:50px;padding-right:50px;border-radius:10px;">
        {{ $message }}
    </span>
</div>

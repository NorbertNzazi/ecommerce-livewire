<div class="hero__search__form" style="background-color:bisque;width:100%;">
    <input type="text" placeholder="Search for a product">
</div>

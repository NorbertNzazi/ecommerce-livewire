<div>
    <!-- Checkout Section Begin -->
    <section class="checkout spad">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-md-6">
                    {{-- // --}}
                </div>

                <div class="col-lg-4 col-md-6">
                    <div class="checkout__order">
                        <h4 style="margin-top: 0px;color:green;">Your payment was successful</h4>

                        <span>Kindly find the receipt, that has been sent to your email</span>
                    </div>
                </div>

                <div class="col-lg-4 col-md-6">
                    {{-- // --}}
                </div>
            </div>
        </div>
    </section>
    <!-- Checkout Section End -->
</div>
